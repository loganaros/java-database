package FBLA;

import java.util.ArrayList;

public class Schedule extends ArrayList {

	public void createSchedule(Employee e) {
		if (e.getShift().equals("Part-Time")) {
			
		}
	}
	
	public Schedule(Employee e) {
		
	}
}