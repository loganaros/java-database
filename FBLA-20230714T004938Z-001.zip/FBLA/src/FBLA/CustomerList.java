package FBLA;

import java.util.ArrayList;

public class CustomerList extends ArrayList<Object> {

	public void insert(Customer c) {
		add(c);
	}
	
	
	
	public CustomerList() {
		// TODO Auto-generated constructor stub
	}

}
