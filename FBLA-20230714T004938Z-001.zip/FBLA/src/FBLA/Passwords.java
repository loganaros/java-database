package FBLA;

public class Passwords {

	public Passwords() {
		// TODO Auto-generated constructor stub
	}

}
